var keystone = require('keystone');

exports = module.exports = function (req, res) {

    var locals = res.locals;


    res.json({});
};
